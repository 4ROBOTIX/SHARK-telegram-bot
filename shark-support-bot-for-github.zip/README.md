# SHARK Support Bot

Telegram bot pro odpovídání na časté otázky ohledně SHARK EA. Nasaditelný např. přes Render nebo Railway.

## Spuštění

```
python main.py
```

## Proměnné prostředí

- `TELEGRAM_BOT_TOKEN` – token z BotFather